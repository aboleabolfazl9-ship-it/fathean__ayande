-- ============================================================
-- سامانه مدیریت مدرسه «فاتحان آینده» — نسخه PHP/MySQL
-- Fatehan Ayande School Management System — Database Schema
-- MySQL / MariaDB  |  charset: utf8mb4
-- اجرا: این فایل به‌صورت خودکار توسط install/index.php اجرا می‌شود.
-- توجه: حساب مدیر توسط نصب‌ساز با password_hash ساخته می‌شود و
--       هیچ رمزی در این فایل ذخیره نشده است.
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------- کاربران (مدیر + دانش‌آموزان) ----------
CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(60) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,          -- password_hash() / password_verify()
  role ENUM('admin','student') NOT NULL DEFAULT 'student',
  must_change_password TINYINT(1) NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  last_login_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- ---------- کلاس‌ها ----------
CREATE TABLE IF NOT EXISTS classes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(20) NOT NULL UNIQUE,             -- ۷/۱ ، ۸/۱ ، ...
  grade TINYINT NOT NULL                        -- 7 / 8 / 9
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO classes (name, grade) VALUES
('۷/۱', 7), ('۸/۱', 8), ('۸/۲', 8), ('۹/۱', 9), ('۹/۲', 9);

-- ---------- دانش‌آموزان ----------
CREATE TABLE IF NOT EXISTS students (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  first_name VARCHAR(60) NOT NULL,
  last_name VARCHAR(60) NOT NULL,
  student_id VARCHAR(20) NOT NULL UNIQUE,       -- شماره دانش‌آموزی یکتا
  class_id INT UNSIGNED NULL,
  status ENUM('pending','approved','rejected','blocked') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- ---------- درخواست‌های ثبت‌نام ----------
CREATE TABLE IF NOT EXISTS registrations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  student_id INT UNSIGNED NOT NULL,
  decision ENUM('approved','rejected') NULL,
  reviewed_by VARCHAR(60) NULL,
  note VARCHAR(255) NULL,
  reviewed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- ---------- دروس ----------
CREATE TABLE IF NOT EXISTS subjects (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  icon VARCHAR(40) DEFAULT 'book-open'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO subjects (name, icon) VALUES
('قرآن','book-open'), ('تعلیمات دینی','moon-star'), ('ادبیات فارسی','pen-line'),
('عربی','languages'), ('زبان انگلیسی','globe'), ('ریاضیات','sigma'),
('علوم تجربی','flask-conical'), ('مطالعات اجتماعی','landmark'), ('هنر','palette'),
('تربیت بدنی','dumbbell'), ('کار و فناوری','cpu'), ('تفکر و سبک زندگی','brain');

-- ---------- نمرات ----------
CREATE TABLE IF NOT EXISTS grades (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  student_id INT UNSIGNED NOT NULL,
  subject_id INT UNSIGNED NOT NULL,
  value DECIMAL(4,2) NOT NULL,                  -- 0 تا 20
  term TINYINT NOT NULL DEFAULT 1,              -- 1 | 2
  type ENUM('مستمر','پایانی') NOT NULL DEFAULT 'پایانی',
  exam_date_j VARCHAR(20) NULL,                 -- تاریخ شمسی مثل 1404/08/20
  note VARCHAR(255) NULL,
  status ENUM('approved','draft') NOT NULL DEFAULT 'approved',
  updated_by VARCHAR(60) NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_grade (student_id, subject_id, term, type),
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- ---------- تاریخچه تغییر نمرات ----------
CREATE TABLE IF NOT EXISTS grade_history (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  grade_id BIGINT UNSIGNED NOT NULL,
  admin VARCHAR(60) NOT NULL,
  old_value DECIMAL(4,2) NULL,
  new_value DECIMAL(4,2) NOT NULL,
  changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (grade_id) REFERENCES grades(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- ---------- امتحانات ----------
CREATE TABLE IF NOT EXISTS exams (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  subject_id INT UNSIGNED NULL,
  class_id INT UNSIGNED NULL,                   -- NULL = همه پایه‌ها
  j_day TINYINT NOT NULL,
  j_month TINYINT NOT NULL,
  j_year SMALLINT NULL,                         -- NULL = بدون سال (مثل امتحان مبتکران)
  description TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE SET NULL,
  FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- امتحان مبتکران — ۲۰ آبان (سال به‌صورت NULL، بدون حدس)
INSERT INTO exams (title, subject_id, class_id, j_day, j_month, j_year, description) VALUES
('امتحان مبتکران', NULL, NULL, 20, 8, NULL,
 'آزمون استعدادیابی و ورودی مبتکران — ویژه داوطلبان جدید مدرسه فاتحان آینده. محل برگزاری: سالن اجتماعات.');

-- ---------- اطلاعیه‌ها ----------
CREATE TABLE IF NOT EXISTS announcements (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(160) NOT NULL,
  body TEXT NOT NULL,
  image VARCHAR(255) NULL,
  category ENUM('عمومی','امتحانات','افتخارات','پرورشی','اداری') NOT NULL DEFAULT 'عمومی',
  published TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO announcements (title, body, category, published) VALUES
('آغاز سال تحصیلی جدید در فاتحان آینده',
 'سال تحصیلی جدید را به دانش‌آموزان و خانواده‌های گرامی تبریک می‌گوییم. کلاس‌ها از شنبه اول مهر ساعت ۷:۳۰ آغاز می‌شوند.',
 'عمومی', 1);

-- ---------- افتخارات ----------
CREATE TABLE IF NOT EXISTS achievements (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  student_id INT UNSIGNED NULL,                 -- NULL = تیم/مدرسه
  title VARCHAR(160) NOT NULL,
  type ENUM('علمی','فرهنگی','انضباطی') NOT NULL,
  medal ENUM('gold','silver','bronze') NOT NULL,
  description TEXT NULL,
  j_date VARCHAR(20) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- ---------- جنم (امتیاز انضباط و مشارکت) ----------
-- موجودی هر دانش‌آموز = مجموع delta تراکنش‌ها (شروع از صفر)
CREATE TABLE IF NOT EXISTS merit_transactions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  student_id INT UNSIGNED NOT NULL,
  delta SMALLINT NOT NULL,                      -- مثبت یا منفی
  reason VARCHAR(160) NOT NULL,                 -- غیبت غیرموجه -10 / سه تأخیر -5 / بی‌نظمی -2 / ...
  admin VARCHAR(60) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- ---------- قرارگاه‌ها ----------
CREATE TABLE IF NOT EXISTS bases (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(30) NOT NULL UNIQUE,
  name VARCHAR(80) NOT NULL,
  icon VARCHAR(40) DEFAULT 'castle',
  color VARCHAR(9) DEFAULT '#3B6BD4',
  manager VARCHAR(80) NULL,
  description TEXT NULL,
  report TEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO bases (slug, name, icon, color) VALUES
('farhangi','قرارگاه فرهنگی','sparkles','#F5B400'),
('media','قرارگاه مدیا','clapperboard','#8B6FD8'),
('nezam','قرارگاه نظم','shield-check','#2FBF8A'),
('danayi','قرارگاه دانایی','graduation-cap','#3B6BD4'),
('energy','قرارگاه انرژی','zap','#F08A5D');

CREATE TABLE IF NOT EXISTS base_members (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  base_id INT UNSIGNED NOT NULL,
  member_name VARCHAR(80) NOT NULL,
  FOREIGN KEY (base_id) REFERENCES bases(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

CREATE TABLE IF NOT EXISTS base_activities (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  base_id INT UNSIGNED NOT NULL,
  title VARCHAR(160) NOT NULL,
  FOREIGN KEY (base_id) REFERENCES bases(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- ---------- تاریخچه فعالیت مدیر ----------
CREATE TABLE IF NOT EXISTS activity_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  actor VARCHAR(60) NOT NULL,
  action VARCHAR(120) NOT NULL,
  detail VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- ---------- تنظیمات ----------
CREATE TABLE IF NOT EXISTS settings (
  skey VARCHAR(60) PRIMARY KEY,
  svalue VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO settings (skey, svalue) VALUES
('school_name','مدرسه فاتحان آینده'),
('slogan','جایی که فردا ساخته می‌شود'),
('installed','0');

SET FOREIGN_KEY_CHECKS = 1;
