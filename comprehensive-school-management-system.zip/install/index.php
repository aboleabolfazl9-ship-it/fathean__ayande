<?php
declare(strict_types=1);
/**
 * نصب‌ساز سامانه مدیریت مدرسه «فاتحان آینده»
 * - بررسی اتصال MySQL با PDO
 * - ساخت جدول‌ها از روی install/database.sql
 * - ایجاد حساب مدیر اولیه با password_hash (admin / admin1234 و تغییر اجباری در اولین ورود)
 * - ثبت نصب اولیه و قفل شدن خودکار (installed.lock)
 */
session_start();

$lockFile = __DIR__ . '/installed.lock';
$installed = file_exists($lockFile);
$errors = [];
$done = false;

if (!$installed && $_SERVER['REQUEST_METHOD'] === 'POST') {
    // توکن CSRF ساده
    if (empty($_POST['csrf']) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
        $errors[] = 'نشست نامعتبر است؛ صفحه را تازه‌سازی کنید.';
    }

    $host = trim($_POST['db_host'] ?? 'localhost');
    $name = trim($_POST['db_name'] ?? '');
    $user = trim($_POST['db_user'] ?? '');
    $pass = (string)($_POST['db_pass'] ?? '');

    if (!$name || !$user) {
        $errors[] = 'نام دیتابیس و نام کاربری الزامی است.';
    }

    if (!$errors) {
        try {
            // ۱) بررسی اتصال دیتابیس
            $pdo = new PDO(
                "mysql:host={$host};dbname={$name};charset=utf8mb4",
                $user,
                $pass,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
            );

            // ۲) ساخت جدول‌ها
            $sql = file_get_contents(__DIR__ . '/database.sql');
            if ($sql === false) throw new RuntimeException('فایل database.sql یافت نشد.');
            $pdo->exec($sql);

            // ۳) ایجاد حساب مدیر اولیه (رمز فقط همین‌جا و با password_hash)
            $hash = password_hash('admin1234', PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role, must_change_password) VALUES ('admin', :h, 'admin', 1)
                                   ON DUPLICATE KEY UPDATE password_hash = :h2, must_change_password = 1");
            $stmt->execute(['h' => $hash, 'h2' => $hash]);

            // ۴) ثبت نصب اولیه + ۵) قفل نصب‌ساز
            $pdo->exec("UPDATE settings SET svalue = '1' WHERE skey = 'installed'");
            file_put_contents($lockFile, date('c'));
            $pdo->prepare("INSERT INTO activity_logs (actor, action, detail) VALUES ('سیستم','نصب اولیه','ساخت جدول‌ها و حساب مدیر')")->execute();

            $done = true;
        } catch (Throwable $e) {
            $errors[] = 'خطا: ' . $e->getMessage();
        }
    }
}

if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>نصب سامانه فاتحان آینده</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css">
<style>
  body{font-family:Vazirmatn,sans-serif;background:#050A14;color:#EDF2FA;display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0}
  .box{background:#0F1A30;border:1px solid #1C2A45;border-radius:20px;padding:34px;width:min(460px,92vw)}
  h1{font-size:20px;margin:0 0 6px} p{color:#8EA0BF;font-size:13px;line-height:2}
  label{display:block;font-size:12.5px;color:#8EA0BF;margin:14px 0 6px}
  input{width:100%;box-sizing:border-box;padding:11px 14px;border-radius:12px;border:1px solid #1C2A45;background:#0B1426;color:#EDF2FA;font-family:inherit}
  button{margin-top:20px;width:100%;padding:12px;border:none;border-radius:13px;background:linear-gradient(135deg,#3B6BD4,#1A3F87);color:#fff;font-family:inherit;font-weight:800;font-size:15px;cursor:pointer}
  .err{background:rgba(239,91,100,.12);border:1px solid rgba(239,91,100,.4);color:#EF5B64;border-radius:12px;padding:11px 14px;font-size:13px;margin-top:14px}
  .ok{background:rgba(47,191,138,.12);border:1px solid rgba(47,191,138,.4);color:#2FBF8A;border-radius:12px;padding:14px;font-size:13.5px;line-height:2}
  code{direction:ltr;display:inline-block;background:#0B1426;border:1px solid #1C2A45;border-radius:7px;padding:1px 8px;font-size:12px}
</style>
</head>
<body>
<div class="box">
<?php if ($installed && !$done): ?>
  <h1>سامانه قبلاً نصب شده است</h1>
  <p>نصب‌ساز پس از نصب موفق قفل می‌شود و دیگر قابل اجرای عمومی نیست. برای نصب مجدد، فایل <code>install/installed.lock</code> را حذف کنید (توصیه نمی‌شود).</p>
  <div class="ok">پوشه <code>install/</code> را پس از نصب از روی هاست حذف کنید.</div>
<?php elseif ($done): ?>
  <h1>نصب با موفقیت انجام شد</h1>
  <div class="ok">
    اتصال دیتابیس برقرار و جدول‌ها ساخته شد.<br>
    حساب مدیر اولیه ایجاد شد: نام کاربری <code>admin</code> — رمز موقت <code>admin1234</code><br>
    در <b>اولین ورود</b>، سامانه شما را مجبور به تعریف رمز امن جدید می‌کند.<br>
    نصب‌ساز اکنون قفل است؛ پوشه <code>install/</code> را حذف کنید.
  </div>
<?php else: ?>
  <h1>نصب‌ساز سامانه فاتحان آینده</h1>
  <p>اطلاعات اتصال MySQL را وارد کنید تا جدول‌ها ساخته و حساب مدیر اولیه ایجاد شود.</p>
  <?php foreach ($errors as $e): ?><div class="err"><?= h($e) ?></div><?php endforeach; ?>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
    <label>میزبان دیتابیس</label><input name="db_host" value="localhost" dir="ltr" required>
    <label>نام دیتابیس</label><input name="db_name" dir="ltr" required>
    <label>نام کاربری دیتابیس</label><input name="db_user" dir="ltr" required>
    <label>رمز دیتابیس</label><input name="db_pass" type="password" dir="ltr">
    <button>شروع نصب</button>
  </form>
<?php endif; ?>
</div>
</body>
</html>
