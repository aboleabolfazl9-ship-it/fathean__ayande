<?php
/**
 * نمونه تنظیمات اتصال دیتابیس — سامانه فاتحان آینده
 * این فایل را به نام config.php در همین پوشه کپی کنید و مقادیر واقعی را وارد نمایید.
 *
 * امنیت:
 * - config.php را در .gitignore قرار دهید و هرگز در مخزن عمومی کامیت نکنید.
 * - روی هاست، این فایل بیرون از public_html یا با محدودیت دسترسی نگه داشته شود.
 */
return [
    'db' => [
        'host'    => 'localhost',      // میزبان MySQL
        'name'    => 'fatehan',        // نام دیتابیس
        'user'    => 'DB_USERNAME',    // نام کاربری دیتابیس
        'pass'    => 'DB_PASSWORD',    // رمز دیتابیس
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'school_name'   => 'مدرسه فاتحان آینده',
        'session_name'  => 'FA_SESSID',
        'session_secure'=> true,       // فقط روی HTTPS
        'login_max_attempts' => 5,
        'login_lock_seconds' => 120,
    ],
];
